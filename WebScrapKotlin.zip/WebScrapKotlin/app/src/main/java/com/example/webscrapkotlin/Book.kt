package com.example.webscrapkotlin

import android.util.Log
import org.jsoup.Jsoup
import kotlin.properties.Delegates

class Book(
    private val url: String
) {
    fun bookPage(): Array<Any> {
        var title by Delegates.notNull<String>()
        var score by Delegates.notNull<Float>()
        var reviewCount by Delegates.notNull<Int>()
        var datePublished by Delegates.notNull<String>()

        val document = Jsoup.connect(url).get()

        title = document.getElementsByTag("title")
            .toString().split("【").first()
            .drop(7)

        var bookContentElement = document.getElementById("book-content")
        var bkCon = Jsoup.parse(bookContentElement.toString())
        var temp = bkCon.getElementsByTag("p")
        var bookContent = temp.toString()
            .replace("<br>","\n")
            .drop(3).dropLast(4)
            .replace("<p>", "\n")
            .replace("</p>", "\n")

        var allEm = document.getElementsByTag("em")
        for (item in allEm){
            if (item.toString().contains("score") ){
                score = item.text().toFloat()
            }
        }
        var allTd = document.getElementsByTag("td")
        for (item in allTd){
            if (item.toString().contains("datePublished") ){
                datePublished = item.text()
            }
        }

        var allSpan = document.getElementsByTag("span")
        for (item in allSpan){
            if (item.toString().contains("reviewCount") ){
                reviewCount = item.text().filter { it.isDigit() }.toInt()
            }
        }
//        Log.v("Book", score.toString() )
//        Log.v("Book", bookContent )
//        Log.v("Book", reviewCount.toString() )
//        Log.v("Book", datePublished )
        return arrayOf(title, datePublished, score, reviewCount, bookContent)
    }
}